Aluno : Victor Akihito Kamada Tomita - 10692082
 
Para rodar o programa utilize o seguinte comando :
        python3 Trab3.py
 
 
 
Em relação aos requisitos do trabalho :
    1) OK
    2) A fonte de luz externa é a lua
    3) OK
    4) OK
    5) A luz fonte é tipo uma lâmpada
    6) Modifiquei o código de fragmento para que existissem kd, ks, ns internos e externos, dentro da casa dos parâmetros externos são baixos, e fora da casa, os parâmetros externos são baixos
    7) OK
    8) OK
    9) OK
    10) É mais notório pelo céu, pela chão da casa, pela TV e pela mesa. Mas em outros modelos isso também é perceptível, como no container, na baleia e no golfinho.
obs : a tecla "i" entre no modo polígono, as teclas "1" e "2", regulam o ka, "3" e "4", regulam o kd, e as teclas "5" e "6" regulam o ks. Talvez o programa fique um pouco travado, porque há muitos modelos sendo carregados e desenhados. Qualquer problema meu e-mail é : akihito012@usp.br.
 
 
Vídeo :
    Desculpa, mas gravei com o celular a tela do computador porque meu computador não aguentava executar o programa e o gravador de vídeo :
    https://youtu.be/cfkdYW8cjHA    
    Mas, caso o senhor queira ver o vídeo gravado pelo capturador de tela, o vídeo não ficou muito bom porque meu computador não é dos melhores. Desta forma, ao rodar o programa e gravar meu computador não aguentou, desculpa... 
    Porém creio que quando o senhor rodar em seu computador irá funcionar melhor, pelo menos quando não estou gravando o programa funciona melhor. 
    Segue o link para o vídeo com gravador de tela :
    https://youtu.be/QFIxYOg8spo
 
 
 
 
Agradecimento:
    Professor muito obrigado pelo semestre, foi muito mais fácil aprender a matéria, principalmente da forma que o senhor nos apresentou. Também queria lhe agradecer por ser paciente e educado, acho que graças à isso pude aprender mais com a matéria e ter interesse nela, antes eu tinha um certo preconceito em relação à CG, mas depois dessas aulas pude me divertir com a matéria. Por fim, muito obrigado por ter me ajudado muito ao longo do semestre e novamente agradeço pela paciência.
 

